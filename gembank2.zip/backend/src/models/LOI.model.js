const mongoose = require('mongoose');

const LOISchema = new mongoose.Schema({
  loiReference: {
    type: String,
    required: true,
    unique: true,
    index: true
  },
  
  businessInfo: {
    businessName: {
      type: String,
      required: true,
      trim: true
    },
    gstin: {
      type: String, // Encrypted
      trim: true
    },
    yearEstablished: {
      type: Number,
      required: true,
      min: 1900,
      max: new Date().getFullYear()
    },
    businessType: {
      type: String,
      required: true,
      enum: ['retail', 'wholesale', 'manufacturing', 'mixed']
    }
  },

  contactInfo: {
    ownerName: {
      type: String,
      required: true,
      trim: true
    },
    designation: {
      type: String,
      trim: true
    },
    email: {
      type: String,
      required: true,
      lowercase: true,
      trim: true,
      match: [/^\S+@\S+\.\S+$/, 'Please use a valid email address']
    },
    phone: {
      type: String, // Encrypted
      required: true
    },
    alternatePhone: {
      type: String // Encrypted
    }
  },

  businessMetrics: {
    annualTurnover: {
      type: String,
      required: true,
      enum: ['below-1cr', '1cr-5cr', '5cr-10cr', '10cr-25cr', '25cr-50cr', 'above-50cr']
    },
    goldInventoryValue: {
      type: String,
      required: true,
      enum: ['below-50l', '50l-1cr', '1cr-5cr', '5cr-10cr', 'above-10cr']
    },
    averageMonthlyTransactions: {
      type: Number
    },
    primarySuppliers: {
      type: String,
      trim: true
    }
  },

  banking: {
    currentBankingPartner: {
      type: String,
      required: true,
      trim: true
    },
    painPoints: [{
      type: String,
      enum: [
        'Slow payment processing',
        'High transaction fees',
        'No gold inventory tracking',
        'Poor customer support',
        'Limited business insights',
        'Complex compliance management',
        'No digital invoicing',
        'Manual record keeping'
      ]
    }],
    softwareCurrentlyUsing: {
      type: String,
      trim: true
    }
  },

  requirements: {
    featuresInterested: [{
      type: String,
      enum: [
        'Gold rate tracking',
        'Inventory management',
        'B2B payments',
        'Digital invoicing',
        'Compliance tracking',
        'Customer management',
        'Analytics dashboard',
        'Multi-branch support'
      ]
    }],
    expectedGoLiveDate: {
      type: Date,
      required: true
    },
    teamSize: {
      type: Number
    },
    branchCount: {
      type: Number
    }
  },

  compliance: {
    panCard: {
      type: String, // Encrypted
      required: true
    },
    hasFSSAILicense: {
      type: Boolean,
      default: false
    },
    hasGSTCompliance: {
      type: Boolean,
      default: false,
      required: true
    },
    hasHallmarkingCertification: {
      type: Boolean,
      default: false
    }
  },

  additionalInfo: {
    referralSource: {
      type: String,
      enum: ['google', 'social-media', 'referral', 'trade-show', 'advertisement', 'other', '']
    },
    comments: {
      type: String,
      maxlength: 1000
    }
  },

  status: {
    type: String,
    enum: ['pending', 'reviewing', 'approved', 'rejected', 'contacted'],
    default: 'pending',
    index: true
  },

  adminNotes: {
    type: String,
    maxlength: 2000
  },

  pdfUrl: {
    type: String
  },

  submittedAt: {
    type: Date,
    default: Date.now,
    index: true
  },

  lastUpdated: {
    type: Date,
    default: Date.now
  }
}, {
  timestamps: true
});

// Indexes for efficient querying
LOISchema.index({ 'contactInfo.email': 1 });
LOISchema.index({ 'businessInfo.businessType': 1 });
LOISchema.index({ 'businessMetrics.annualTurnover': 1 });
LOISchema.index({ status: 1, submittedAt: -1 });

// Pre-save middleware to update lastUpdated
LOISchema.pre('save', function(next) {
  this.lastUpdated = Date.now();
  next();
});

module.exports = mongoose.model('LOI', LOISchema);