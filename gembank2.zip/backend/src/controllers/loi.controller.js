const LOI = require('../models/LOI.model');
const { generateLOIPDF } = require('../services/pdf.service');
const { sendLOIEmail } = require('../services/email.service');
const { encrypt } = require('../services/encryption.service');

/**
 * Submit Letter of Interest
 * @route POST /api/loi/submit
 * @access Public (with rate limiting)
 */
exports.submitLOI = async (req, res) => {
  try {
    const {
      businessName,
      gstin,
      yearEstablished,
      businessType,
      ownerName,
      designation,
      email,
      phone,
      alternatePhone,
      annualTurnover,
      goldInventoryValue,
      averageMonthlyTransactions,
      primarySuppliers,
      currentBankingPartner,
      painPoints,
      softwareCurrentlyUsing,
      featuresInterested,
      expectedGoLiveDate,
      teamSize,
      branchCount,
      panCard,
      hasFSSAILicense,
      hasGSTCompliance,
      hasHallmarkingCertification,
      referralSource,
      comments
    } = req.body;

    // Validate required fields
    if (!businessName || !ownerName || !email || !phone || !annualTurnover || !panCard) {
      return res.status(400).json({
        success: false,
        message: 'Missing required fields'
      });
    }

    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return res.status(400).json({
        success: false,
        message: 'Invalid email format'
      });
    }

    // Validate PAN format
    const panRegex = /^[A-Z]{5}[0-9]{4}[A-Z]$/;
    if (!panRegex.test(panCard)) {
      return res.status(400).json({
        success: false,
        message: 'Invalid PAN card format'
      });
    }

    // Encrypt sensitive data
    const encryptedPAN = encrypt(panCard);
    const encryptedPhone = encrypt(phone);
    const encryptedGSTIN = gstin ? encrypt(gstin) : null;

    // Generate unique LOI reference number
    const loiReference = `LOI-${Date.now()}-${Math.random().toString(36).substr(2, 9).toUpperCase()}`;

    // Create LOI document in database
    const loi = await LOI.create({
      loiReference,
      businessInfo: {
        businessName,
        gstin: encryptedGSTIN,
        yearEstablished,
        businessType
      },
      contactInfo: {
        ownerName,
        designation,
        email,
        phone: encryptedPhone,
        alternatePhone: alternatePhone ? encrypt(alternatePhone) : null
      },
      businessMetrics: {
        annualTurnover,
        goldInventoryValue,
        averageMonthlyTransactions,
        primarySuppliers
      },
      banking: {
        currentBankingPartner,
        painPoints,
        softwareCurrentlyUsing
      },
      requirements: {
        featuresInterested,
        expectedGoLiveDate,
        teamSize,
        branchCount
      },
      compliance: {
        panCard: encryptedPAN,
        hasFSSAILicense,
        hasGSTCompliance,
        hasHallmarkingCertification
      },
      additionalInfo: {
        referralSource,
        comments
      },
      status: 'pending',
      submittedAt: new Date()
    });

    // Generate PDF document
    const pdfBuffer = await generateLOIPDF({
      loiReference,
      ...req.body,
      submittedDate: new Date().toLocaleDateString('en-IN')
    });

    // Upload PDF to S3 or save locally (for dev)
    const pdfUrl = await savePDF(pdfBuffer, loiReference);

    // Update LOI with PDF URL
    loi.pdfUrl = pdfUrl;
    await loi.save();

    // Send confirmation email with PDF attachment
    await sendLOIEmail({
      to: email,
      businessName,
      ownerName,
      loiReference,
      pdfBuffer
    });

    // Send notification to admin
    await sendLOIEmail({
      to: process.env.ADMIN_EMAIL,
      businessName,
      ownerName,
      loiReference,
      pdfBuffer,
      isAdmin: true
    });

    // Log analytics event
    // await logAnalyticsEvent('loi_submit', { loiReference, businessType, annualTurnover });

    res.status(201).json({
      success: true,
      message: 'LOI submitted successfully',
      data: {
        loiReference,
        pdfUrl,
        submittedAt: loi.submittedAt
      }
    });

  } catch (error) {
    console.error('LOI Submission Error:', error);
    
    res.status(500).json({
      success: false,
      message: 'Failed to submit LOI. Please try again.',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
};

/**
 * Get LOI by reference number
 * @route GET /api/loi/:reference
 * @access Private (Admin only)
 */
exports.getLOIByReference = async (req, res) => {
  try {
    const { reference } = req.params;

    const loi = await LOI.findOne({ loiReference: reference });

    if (!loi) {
      return res.status(404).json({
        success: false,
        message: 'LOI not found'
      });
    }

    // Decrypt sensitive data for admin view
    const decryptedLOI = {
      ...loi.toObject(),
      contactInfo: {
        ...loi.contactInfo,
        phone: decrypt(loi.contactInfo.phone),
        alternatePhone: loi.contactInfo.alternatePhone ? decrypt(loi.contactInfo.alternatePhone) : null
      },
      businessInfo: {
        ...loi.businessInfo,
        gstin: loi.businessInfo.gstin ? decrypt(loi.businessInfo.gstin) : null
      },
      compliance: {
        ...loi.compliance,
        panCard: decrypt(loi.compliance.panCard)
      }
    };

    res.status(200).json({
      success: true,
      data: decryptedLOI
    });

  } catch (error) {
    console.error('Get LOI Error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to retrieve LOI'
    });
  }
};

/**
 * Get all LOIs with filters
 * @route GET /api/loi/admin/list
 * @access Private (Admin only)
 */
exports.getAllLOIs = async (req, res) => {
  try {
    const {
      page = 1,
      limit = 20,
      status,
      businessType,
      annualTurnover,
      sortBy = 'submittedAt',
      sortOrder = 'desc'
    } = req.query;

    const query = {};

    if (status) query.status = status;
    if (businessType) query['businessInfo.businessType'] = businessType;
    if (annualTurnover) query['businessMetrics.annualTurnover'] = annualTurnover;

    const skip = (page - 1) * limit;

    const lois = await LOI.find(query)
      .sort({ [sortBy]: sortOrder === 'desc' ? -1 : 1 })
      .skip(skip)
      .limit(parseInt(limit))
      .select('-contactInfo.phone -businessInfo.gstin -compliance.panCard'); // Exclude sensitive data from list view

    const total = await LOI.countDocuments(query);

    res.status(200).json({
      success: true,
      data: {
        lois,
        pagination: {
          currentPage: parseInt(page),
          totalPages: Math.ceil(total / limit),
          totalItems: total,
          itemsPerPage: parseInt(limit)
        }
      }
    });

  } catch (error) {
    console.error('Get All LOIs Error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to retrieve LOIs'
    });
  }
};

/**
 * Update LOI status
 * @route PATCH /api/loi/:reference/status
 * @access Private (Admin only)
 */
exports.updateLOIStatus = async (req, res) => {
  try {
    const { reference } = req.params;
    const { status, adminNotes } = req.body;

    const validStatuses = ['pending', 'reviewing', 'approved', 'rejected', 'contacted'];
    
    if (!validStatuses.includes(status)) {
      return res.status(400).json({
        success: false,
        message: 'Invalid status value'
      });
    }

    const loi = await LOI.findOneAndUpdate(
      { loiReference: reference },
      {
        status,
        adminNotes,
        lastUpdated: new Date()
      },
      { new: true }
    );

    if (!loi) {
      return res.status(404).json({
        success: false,
        message: 'LOI not found'
      });
    }

    // Send status update email to applicant
    if (status === 'approved' || status === 'rejected') {
      // await sendStatusUpdateEmail(loi.contactInfo.email, status, loi.businessInfo.businessName);
    }

    res.status(200).json({
      success: true,
      message: 'LOI status updated successfully',
      data: loi
    });

  } catch (error) {
    console.error('Update LOI Status Error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to update LOI status'
    });
  }
};

/**
 * Get LOI statistics
 * @route GET /api/loi/admin/stats
 * @access Private (Admin only)
 */
exports.getLOIStats = async (req, res) => {
  try {
    const totalLOIs = await LOI.countDocuments();
    
    const statusBreakdown = await LOI.aggregate([
      {
        $group: {
          _id: '$status',
          count: { $sum: 1 }
        }
      }
    ]);

    const businessTypeBreakdown = await LOI.aggregate([
      {
        $group: {
          _id: '$businessInfo.businessType',
          count: { $sum: 1 }
        }
      }
    ]);

    const turnoverBreakdown = await LOI.aggregate([
      {
        $group: {
          _id: '$businessMetrics.annualTurnover',
          count: { $sum: 1 }
        }
      }
    ]);

    const recentLOIs = await LOI.find()
      .sort({ submittedAt: -1 })
      .limit(5)
      .select('loiReference businessInfo.businessName contactInfo.email status submittedAt');

    res.status(200).json({
      success: true,
      data: {
        totalLOIs,
        statusBreakdown,
        businessTypeBreakdown,
        turnoverBreakdown,
        recentLOIs
      }
    });

  } catch (error) {
    console.error('Get LOI Stats Error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to retrieve statistics'
    });
  }
};

// Helper function to save PDF (implement based on your storage solution)
async function savePDF(pdfBuffer, loiReference) {
  // For local development
  const fs = require('fs').promises;
  const path = require('path');
  
  const uploadsDir = path.join(__dirname, '../../uploads/loi-pdfs');
  await fs.mkdir(uploadsDir, { recursive: true });
  
  const filename = `${loiReference}.pdf`;
  const filepath = path.join(uploadsDir, filename);
  
  await fs.writeFile(filepath, pdfBuffer);
  
  return `/uploads/loi-pdfs/${filename}`;
  
  // For production with S3
  // const AWS = require('aws-sdk');
  // const s3 = new AWS.S3();
  // const params = {
  //   Bucket: process.env.AWS_S3_BUCKET,
  //   Key: `loi-pdfs/${loiReference}.pdf`,
  //   Body: pdfBuffer,
  //   ContentType: 'application/pdf'
  // };
  // const result = await s3.upload(params).promise();
  // return result.Location;
}