import { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import Button from './Button';


const Navbar = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { label: 'Why GEMBank', href: '/why' },
    { label: 'Features', href: '/features' },
    { label: 'Pricing', href: '/features#pricing' },
    { label: 'Contact', href: '/contact' },
  ];

  const isActive = (path) => {
    // Handle hash-aware links like "/features#pricing"
    if (path.includes('#')) {
      const [base, hash] = path.split('#');
      const onBase = location.pathname.startsWith(base);
      const onHash = location.hash === `#${hash}`;
      return onBase && onHash; // Only active when the specific hash is present
    }
    // Special case: plain "/features" should only be active when there is no hash
    if (path === '/features') {
      return location.pathname.startsWith('/features') && !location.hash;
    }
    return location.pathname === path || location.pathname.startsWith(path);
  };

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled || isMobileMenuOpen
          ? 'bg-soft-white/90 backdrop-blur-lg shadow-soft'
          : 'bg-transparent'
      }`}
    >
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-3 group">
            <div className="w-10 h-10 bg-gradient-to-br from-gembank-gold-light to-gembank-gold rounded-xl flex items-center justify-center transform group-hover:scale-110 transition-transform duration-300">
              <span className="text-2xl">💎</span>
            </div>
            <span className="text-2xl font-display font-bold">
              <span className="text-gembank-gold">GEM</span>
              <span className="text-soft-black">Bank</span>
            </span>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden lg:flex items-center gap-8">
            {navLinks.map((link) => (
              <Link
                key={link.href}
                to={link.href}
                className={`text-sm font-medium transition-colors duration-200 ${
                  isActive(link.href)
                    ? 'text-gembank-gold'
                    : 'text-charcoal-gray hover:text-gembank-gold'
                }`}
              >
                {link.label}
              </Link>
            ))}
          </div>

          {/* Desktop CTA + Language */}
          <div className="hidden lg:flex items-center gap-4">
            {/* <LanguageSelector /> */}
            
            <Link to="/login">
              <Button
                variant="outline"
                size="sm"
                className="border-light-gray"
              >
                Login
              </Button>
            </Link>

            <Link to="/loi">
              <Button
                variant="primary"
                size="sm"
              >
                Book Pilot
              </Button>
            </Link>
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="lg:hidden text-charcoal-gray p-2"
            aria-label="Toggle menu"
          >
            {isMobileMenuOpen ? (
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            ) : (
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
              </svg>
            )}
          </button>
        </div>

        {/* Mobile Menu */}
        {isMobileMenuOpen && (
          <div className="lg:hidden border-t border-light-gray py-4 animate-fade-in">
            <div className="flex flex-col gap-4">
              {navLinks.map((link) => (
                <Link
                  key={link.href}
                  to={link.href}
                  onClick={() => setIsMobileMenuOpen(false)}
                  className={`px-4 py-2 text-sm font-medium transition-colors ${
                    isActive(link.href)
                      ? 'text-gembank-gold bg-gembank-gold/10 rounded-xl'
                      : 'text-charcoal-gray hover:text-gembank-gold hover:bg-gembank-gold/5 rounded-xl'
                  }`}
                >
                  {link.label}
                </Link>
              ))}
              
              <div className="border-t border-light-gray pt-4 px-4 flex flex-col gap-3">
                <Link to="/login" onClick={() => setIsMobileMenuOpen(false)}>
                  <Button
                    variant="outline"
                    size="md"
                    className="w-full border-light-gray"
                  >
                    Login
                  </Button>
                </Link>

                <Link to="/loi" onClick={() => setIsMobileMenuOpen(false)}>
                  <Button
                    variant="primary"
                    size="md"
                  >
                    Book Pilot Program
                  </Button>
                </Link>

                {/* <div className="mt-2">
                  <LanguageSelector />
                </div> */}
              </div>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
};

export default Navbar;