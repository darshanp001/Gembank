// Mock API - No backend required
const api = {
  post: async (url, data) => {
    console.log('Mock POST:', url, data);
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    // Mock responses
    if (url === '/auth/login') {
      return {
        data: {
          success: true,
          user: { name: 'Test User', email: 'test@example.com' },
          token: 'mock_token_123'
        }
      };
    }
    
    if (url === '/auth/register') {
      return {
        data: {
          success: true,
          user: { name: data.ownerName, email: data.email },
          token: 'mock_token_123'
        }
      };
    }
    
    if (url === '/loi/submit') {
      return {
        data: {
          success: true,
          loiReference: `LOI-${Date.now()}`,
          pdfUrl: 'https://example.com/mock.pdf',
          submittedAt: new Date().toISOString()
        }
      };
    }
    
    return { data: { success: true, message: 'Mock response' } };
  },
  
  get: async (url) => {
    console.log('Mock GET:', url);
    await new Promise(resolve => setTimeout(resolve, 500));
    
    if (url === '/auth/me') {
      return {
        data: {
          name: 'Test User',
          email: 'test@example.com',
          businessName: 'Test Jewellers'
        }
      };
    }
    
    return { data: { success: true } };
  },
  
  patch: async (url, data) => {
    console.log('Mock PATCH:', url, data);
    await new Promise(resolve => setTimeout(resolve, 500));
    return { data: { success: true } };
  }
};

export default api;