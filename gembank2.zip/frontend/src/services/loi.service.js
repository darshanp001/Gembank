import api from './api';

export const submitLOI = async (formData) => {
  const response = await api.post('/loi/submit', formData);
  return response.data;
};