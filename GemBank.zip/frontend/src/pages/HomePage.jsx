import Navbar from '../components/common/Navbar';
import Footer from '../components/common/Footer';
import HeroSection from '../components/home/HeroSection';
import { TrustStrip } from '../components/home/TrustStrip';
import KeyFeaturesSection from '../components/home/KeyFeaturesSection';
import NeobankExplainer from '../components/home/NeobankExplainer';
import { SocialProof } from '../components/home/SocialProof';
import CTASection from '../components/home/CTASection';
import { CookieBanner } from '../components/common/CookieBanner';

const HomePage = () => {
  return (
    <div className="min-h-screen bg-white">
      <Navbar />
      <HeroSection />
      <TrustStrip />
      {/* <KeyFeaturesSection /> */}
      {/* <NeobankExplainer /> */}
      {/* <SocialProof /> */}
      <CTASection />
      <Footer />
      {/* <CookieBanner /> */}
    </div> 
  );
};

export default HomePage;