import Navbar from '../components/common/Navbar';
import Footer from '../components/common/Footer';
import LOIForm from '../components/loi/LOIForm';
import { Gift, DollarSign, Handshake, Sparkles } from 'lucide-react';  // ✅ Lucide icons

const LOIPage = () => {
  return (
    <div className="min-h-screen bg-white">
      <Navbar />

      {/* Hero Banner */}
      <section className="relative pt-32 pb-12 bg-gradient-to-br from-white via-gembank-gold/10 to-gembank-gold/30">
  {/* soft golden glow overlay */}
  <div className="absolute inset-0 bg-gradient-to-tr from-gembank-gold/10 via-transparent to-white opacity-70 blur-2xl pointer-events-none"></div>

  <div className="relative container mx-auto px-4 sm:px-6 lg:px-8 text-center">
    <div className="inline-block mb-4">
      <span className="px-4 py-2 bg-gembank-gold/15 border border-gembank-gold/50 rounded-full text-gembank-gold font-medium backdrop-blur-sm shadow-gold inline-flex items-center gap-2">
        <Sparkles className="w-5 h-5 text-gembank-gold animate-pulse" />
        Join Our Pilot Program
      </span>
    </div>
    <h1 className="text-4xl sm:text-5xl font-display font-bold text-gembank-charcoal leading-tight mb-4 drop-shadow-sm">
      Letter of Interest
    </h1>
    <p className="text-xl text-gembank-gray-800 max-w-2xl mx-auto">
      Help us understand your business needs and get priority access to GEMBank
    </p>
  </div>
</section>

      {/* Benefits Section */}
      <section className="py-12 bg-white border-b border-gembank-gray-200">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">

            {/* Card 1 */}
            <div className="text-center group transition-all">
              <div className="w-16 h-16 rounded-full mx-auto mb-4 bg-gradient-to-br from-gembank-gold/30 to-gembank-gold/60 shadow-gold flex items-center justify-center backdrop-blur-sm group-hover:scale-105 transition">
                <Gift className="w-8 h-8 text-gembank-charcoal" strokeWidth={2.5} />
              </div>
              <h3 className="font-bold text-gembank-charcoal mb-2">Early Access</h3>
              <p className="text-sm text-gembank-gray-800">
                Be among the first to experience GEMBank's full feature set
              </p>
            </div>

            {/* Card 2 */}
            <div className="text-center group transition-all">
              <div className="w-16 h-16 rounded-full mx-auto mb-4 bg-gradient-to-br from-gembank-purple/30 to-gembank-purple/60 shadow-md flex items-center justify-center backdrop-blur-sm group-hover:scale-105 transition">
                <DollarSign className="w-8 h-8 text-white" strokeWidth={2.5} />
              </div>
              <h3 className="font-bold text-gembank-charcoal mb-2">Special Pricing</h3>
              <p className="text-sm text-gembank-gray-800">
                Exclusive pilot program discounts for early adopters
              </p>
            </div>

            {/* Card 3 */}
            <div className="text-center group transition-all">
              <div className="w-16 h-16 rounded-full mx-auto mb-4 bg-gradient-to-br from-gembank-green/30 to-gembank-green/60 shadow-md flex items-center justify-center backdrop-blur-sm group-hover:scale-105 transition">
                <Handshake className="w-8 h-8 text-white" strokeWidth={2.5} />
              </div>
              <h3 className="font-bold text-gembank-charcoal mb-2">Dedicated Support</h3>
              <p className="text-sm text-gembank-gray-800">
                Personal onboarding and training from our team
              </p>
            </div>

          </div>
        </div>
      </section>

      {/* Form Section */}
      <LOIForm />

      {/* FAQ Quick Links */}
      <section className="py-12 bg-gembank-gray-50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h3 className="text-xl font-bold text-gembank-charcoal mb-4">
            Questions about the pilot program?
          </h3>
          <div className="flex flex-wrap justify-center gap-4">
            <a href="/features" className="text-gembank-gold hover:underline">
              View Features →
            </a>
            <span className="text-gembank-gray-400">•</span>
            <a href="/help" className="text-gembank-gold hover:underline">
              Help Center →
            </a>
            <span className="text-gembank-gray-400">•</span>
            <a href="/contact" className="text-gembank-gold hover:underline">
              Contact Us →
            </a>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default LOIPage;
