import { useEffect, useRef } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import Navbar from '../components/common/Navbar';
import Footer from '../components/common/Footer';
import ProblemSolutionFlow from '../components/features/ProblemSolutionFlow';
import ThreeStepVisual from '../components/features/ThreeStepVisual';
import FeatureGrid from '../components/features/FeatureGrid';
import PricingTable from '../components/features/PricingTable';
import FAQAccordion from '../components/features/FAQAccordion';
import Button from '../components/common/Button';

const FeaturesPage = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const pricingRef = useRef(null);

  // Scrollspy: update hash to #pricing when pricing section is in view,
  // and clear the hash when section is out of view so only one nav item is active.
  useEffect(() => {
    if (!pricingRef.current) return;
    const el = pricingRef.current;
    const observer = new IntersectionObserver(
      ([entry]) => {
        const currentlyHasHash = location.hash === '#pricing';
        if (entry.isIntersecting) {
          if (!currentlyHasHash) history.replaceState(null, '', '#pricing');
        } else if (currentlyHasHash) {
          history.replaceState(null, '', location.pathname + location.search);
        }
      },
      { rootMargin: '-40% 0px -50% 0px', threshold: 0 }
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, [location.pathname]);

  return (
    <div className="min-h-screen bg-white">
      <Navbar />
      
      {/* Hero Section */}
      <section className="pt-32 pb-20 bg-gray-50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center">
          
          <div className="inline-block mb-4">
            <span className="px-4 py-2 bg-gembank-gold/10 border border-gembank-gold/30 rounded-full text-gembank-gold text-sm font-medium">
              ✨ Features & Pricing
            </span>
          </div>
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-display font-bold text-gray-800 leading-tight mb-6">
            Everything Your Jewellery Business
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-gembank-gold to-gembank-gold-light"> Needs in One Platform</span>
          </h1>
          <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
            From gold rate tracking to compliance management, GEMBank provides all the tools to modernize your jewellery business operations.
          </p>
        </div>
      </section>

      {/* Problem-Solution Flow */}
      <ProblemSolutionFlow />

      {/* Three Step Visual */}
      <ThreeStepVisual />

      {/* Feature Grid */}
      <FeatureGrid />

      {/* Pricing Section */}
      <section id="pricing" ref={pricingRef} className="py-20 bg-gembank-gray-50 scroll-mt-24">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl font-display font-bold text-gembank-charcoal mb-4">
              Simple, Transparent Pricing
            </h2>
            <p className="text-lg text-gembank-gray-800 max-w-2xl mx-auto">
              Choose the plan that fits your business size. All plans include our core features with varying limits.
            </p>
          </div>
          <PricingTable />
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl font-display font-bold text-gembank-charcoal mb-4">
              Frequently Asked Questions
            </h2>
            <p className="text-lg text-gembank-gray-800 max-w-2xl mx-auto">
              Got questions? We've got answers. Can't find what you're looking for? Contact our support team.
            </p>
          </div>
          <FAQAccordion />
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-br from-gembank-charcoal to-gembank-navy">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl sm:text-4xl font-display font-bold text-white mb-6">
            Ready to Transform Your Business?
          </h2>
          <p className="text-xl text-gembank-gray-200 mb-8 max-w-2xl mx-auto">
            Join 200+ jewellers who are already using GEMBank to streamline their operations
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button
              variant="primary"
              size="lg"
              onClick={() => navigate('/signup')}
              className="bg-gembank-gold hover:bg-gembank-gold-dark text-gembank-charcoal font-semibold shadow-gold"
            >
              Start Free Trial
            </Button>
            <Button
              variant="outline"
              size="lg"
              onClick={() => navigate('/loi')}
              className="border-2 border-gembank-gold text-gembank-gold hover:bg-gembank-gold hover:text-gembank-charcoal"
            >
              Book a Demo
            </Button>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default FeaturesPage;