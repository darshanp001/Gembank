const FeatureGrid = () => {
  const features = [
    {
      icon: '📈',
      title: 'Live Gold Rate Tracking',
      description: 'Real-time gold prices with historical charts and price alerts',
      color: 'from-yellow-400 to-gembank-gold',
      stats: 'Updated every 30 seconds'
    },
    {
      icon: '💎',
      title: 'Smart Inventory Management',
      description: 'Track every piece with SKU, weight, purity, and real-time valuation',
      color: 'from-purple-400 to-gembank-purple',
      stats: '99.9% accuracy'
    },
    {
      icon: '💳',
      title: 'Zero-Fee B2B Payments',
      description: 'Transfer funds to suppliers and partners without transaction charges',
      color: 'from-blue-400 to-gembank-blue',
      stats: 'Save ₹40L+ annually'
    },
    {
      icon: '📊',
      title: 'Analytics Dashboard',
      description: 'Sales trends, inventory turnover, profit margins - all in one view',
      color: 'from-green-400 to-gembank-green',
      stats: '15+ report types'
    },
    {
      icon: '📱',
      title: 'Digital Invoicing',
      description: 'Generate GST-compliant invoices instantly with QR code payments',
      color: 'from-teal-400 to-gembank-teal',
      stats: 'E-way bill ready'
    },
    {
      icon: '🔐',
      title: 'Compliance Manager',
      description: 'Auto-track hallmarking, GST filing, and BIS certifications',
      color: 'from-red-400 to-gembank-red',
      stats: '100% audit-ready'
    },
    {
      icon: '👥',
      title: 'Customer Database',
      description: 'Store customer preferences, purchase history, and loyalty points',
      color: 'from-indigo-400 to-purple-500',
      stats: 'Unlimited contacts'
    },
    {
      icon: '🏢',
      title: 'Multi-Branch Support',
      description: 'Manage multiple outlets with centralized control and reporting',
      color: 'from-pink-400 to-red-400',
      stats: 'Up to 50 branches'
    },
    {
      icon: '📤',
      title: 'Supplier Management',
      description: 'Track orders, payments, and delivery schedules with vendors',
      color: 'from-orange-400 to-yellow-500',
      stats: 'Smart reminders'
    },
    {
      icon: '🔔',
      title: 'Smart Notifications',
      description: 'Price alerts, low stock warnings, payment reminders via SMS/email',
      color: 'from-cyan-400 to-blue-500',
      stats: 'Real-time alerts'
    },
    {
      icon: '📄',
      title: 'Document Vault',
      description: 'Securely store certificates, licenses, and business documents',
      color: 'from-emerald-400 to-green-500',
      stats: 'Bank-grade encryption'
    },
    {
      icon: '🤝',
      title: 'Partnership Network',
      description: 'Connect with verified suppliers, refiners, and wholesale partners',
      color: 'from-violet-400 to-purple-600',
      stats: '500+ partners'
    }
  ];

  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <span className="inline-block px-4 py-2 bg-gembank-gold/10 border border-gembank-gold/30 rounded-full text-gembank-gold text-sm font-medium mb-4">
            All Features
          </span>
          <h2 className="text-3xl sm:text-4xl font-display font-bold text-gembank-charcoal mb-4">
            Everything You Need to Run Your Business
          </h2>
          <p className="text-lg text-gembank-gray-800 max-w-2xl mx-auto">
            Comprehensive tools designed specifically for jewellery businesses of all sizes
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {features.map((feature, index) => (
            <div
              key={index}
              className="group relative bg-white border-2 border-gembank-gray-200 rounded-xl p-6 hover:border-gembank-gold hover:shadow-gold transition-all duration-300 cursor-pointer"
            >
              {/* Icon with Gradient Background */}
              <div className={`w-14 h-14 mb-4 bg-gradient-to-br ${feature.color} rounded-lg flex items-center justify-center text-3xl transform group-hover:scale-110 group-hover:rotate-6 transition-all duration-300`}>
                {feature.icon}
              </div>

              {/* Title */}
              <h3 className="text-lg font-bold text-gembank-charcoal mb-2 group-hover:text-gembank-gold transition-colors">
                {feature.title}
              </h3>

              {/* Description */}
              <p className="text-sm text-gembank-gray-800 mb-4 leading-relaxed">
                {feature.description}
              </p>

              {/* Stats Badge */}
              <div className="inline-block px-3 py-1 bg-gembank-gray-100 rounded-full text-xs font-semibold text-gembank-gray-800">
                {feature.stats}
              </div>

              {/* Hover Effect Arrow */}
              <div className="absolute top-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                <svg className="w-5 h-5 text-gembank-gold" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" />
                </svg>
              </div>
            </div>
          ))}
        </div>

        {/* Bottom CTA */}
        <div className="mt-16 text-center">
          <div className="inline-block bg-gembank-gray-50 border border-gembank-gray-300 rounded-2xl p-8">
            <h3 className="text-2xl font-bold text-gembank-charcoal mb-3">
              Want a detailed feature walkthrough?
            </h3>
            <p className="text-gembank-gray-800 mb-6">
              Schedule a personalized demo with our product experts
            </p>
            <button className="px-8 py-3 bg-gembank-gold hover:bg-gembank-gold-dark text-gembank-charcoal font-semibold rounded-lg transition-all duration-300 shadow-gold transform hover:scale-105">
              Book a Demo →
            </button>
          </div>
        </div>

        {/* Integration Badges */}
        <div className="mt-16 text-center">
          <p className="text-sm text-gembank-gray-800 mb-6 font-medium">INTEGRATES WITH YOUR EXISTING TOOLS</p>
          <div className="flex flex-wrap justify-center gap-8 items-center opacity-60">
            <div className="px-6 py-3 bg-white border border-gembank-gray-300 rounded-lg font-semibold text-gembank-gray-800">
              Tally ERP
            </div>
            <div className="px-6 py-3 bg-white border border-gembank-gray-300 rounded-lg font-semibold text-gembank-gray-800">
              GST Portal
            </div>
            <div className="px-6 py-3 bg-white border border-gembank-gray-300 rounded-lg font-semibold text-gembank-gray-800">
              BIS Portal
            </div>
            <div className="px-6 py-3 bg-white border border-gembank-gray-300 rounded-lg font-semibold text-gembank-gray-800">
              NSDL
            </div>
            <div className="px-6 py-3 bg-white border border-gembank-gray-300 rounded-lg font-semibold text-gembank-gray-800">
              WhatsApp Business
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default FeatureGrid;