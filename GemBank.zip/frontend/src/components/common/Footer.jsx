import { Link } from 'react-router-dom';
import {
  Gem,
  ShieldCheck,
  BadgeCheck,
  Apple,
  Play,
  Globe,
  Twitter,
  Linkedin,
  Facebook,
  Instagram,
  Youtube
} from 'lucide-react';

const Footer = () => {
  const footerLinks = {
    product: [
      { name: 'Features', href: '/features' },
      { name: 'Pricing', href: '/features#pricing' },
      { name: 'Integrations', href: '/integrations' },
      { name: 'API Documentation', href: '/api-docs' },
      { name: 'Roadmap', href: '/roadmap' }
    ],
    company: [
      { name: 'About Us', href: '/about' },
      { name: 'Careers', href: '/careers' },
      { name: 'Press Kit', href: '/press' },
      { name: 'Contact', href: '/contact' },
      { name: 'Blog', href: '/blog' }
    ],
    resources: [
      { name: 'Help Center', href: '/help' },
      { name: 'Video Tutorials', href: '/tutorials' },
      { name: 'Community Forum', href: '/community' },
      { name: 'Webinars', href: '/webinars' },
      { name: 'Case Studies', href: '/case-studies' }
    ],
    legal: [
      { name: 'Privacy Policy', href: '/privacy' },
      { name: 'Terms of Service', href: '/terms' },
      { name: 'Cookie Policy', href: '/cookies' },
      { name: 'Compliance', href: '/compliance' },
      { name: 'Security', href: '/security' }
    ]
  };

  const socialLinks = [
    { name: 'Twitter', Icon: Twitter, href: 'https://twitter.com/gembank' },
    { name: 'LinkedIn', Icon: Linkedin, href: 'https://linkedin.com/company/gembank' },
    { name: 'Facebook', Icon: Facebook, href: 'https://facebook.com/gembank' },
    { name: 'Instagram', Icon: Instagram, href: 'https://instagram.com/gembank' },
    { name: 'YouTube', Icon: Youtube, href: 'https://youtube.com/@gembank' }
  ];

  return (
    <footer className="bg-gray-100 text-gray-800">
      {/* Main Footer Content */}
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-8">
          
          {/* Brand Column */}
          <div className="col-span-2">
            <Link to="/" className="flex items-center gap-3 mb-6">
              <div className="w-12 h-12 bg-gradient-to-br from-gembank-gold-light to-gembank-gold rounded-xl flex items-center justify-center">
                <Gem className="w-7 h-7 text-gembank-charcoal" />
              </div>
              <span className="text-2xl font-display font-bold">
                <span className="text-gembank-gold">GEM</span>
                <span className="text-soft-black">Bank</span>
              </span>
            </Link>
            <p className="text-gray-600 mb-6 max-w-xs leading-relaxed">
              Banking designed exclusively for Indian jewellery businesses. Manage inventory, track gold rates, and process payments—all in one platform.
            </p>
            
            {/* Trust Badges */}
            <div className="flex flex-wrap gap-3 mb-6">
              <div className="px-3 py-1.5 bg-gembank-gold/10 rounded-md text-xs font-semibold text-gembank-gold border border-gembank-gold/30 inline-flex items-center gap-1.5">
                <ShieldCheck className="w-3.5 h-3.5" /> RBI Compliant
              </div>
              <div className="px-3 py-1.5 bg-gembank-green/10 rounded-md text-xs font-semibold text-gembank-green border border-gembank-green/30 inline-flex items-center gap-1.5">
                <BadgeCheck className="w-3.5 h-3.5" /> ISO 27001
              </div>
            </div>

            {/* App Download Buttons */}
            <div className="flex flex-col sm:flex-row gap-3">
              <a href="#" className="inline-flex items-center gap-2 px-4 py-2 bg-white hover:bg-gray-50 border border-gray-200 rounded-xl transition-all">
                <Apple className="w-5 h-5 text-gray-700" />
                <div className="text-left">
                  <div className="text-xs text-gray-500">Download on</div>
                  <div className="text-sm font-semibold text-gray-800">App Store</div>
                </div>
              </a>
              <a href="#" className="inline-flex items-center gap-2 px-4 py-2 bg-white hover:bg-gray-50 border border-gray-200 rounded-xl transition-all">
                <Play className="w-5 h-5 text-gray-700" />
                <div className="text-left">
                  <div className="text-xs text-gray-500">Get it on</div>
                  <div className="text-sm font-semibold text-gray-800">Google Play</div>
                </div>
              </a>
            </div>
          </div>

          {/* Product Links */}
          <div>
            <h3 className="font-bold text-gray-900 mb-4">Product</h3>
            <ul className="space-y-3">
              {footerLinks.product.map((link) => (
                <li key={link.name}>
                  <Link 
                    to={link.href}
                    className="text-gray-600 hover:text-gembank-gold transition-colors text-sm"
                  >
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Company Links */}
          <div>
            <h3 className="font-bold text-gray-900 mb-4">Company</h3>
            <ul className="space-y-3">
              {footerLinks.company.map((link) => (
                <li key={link.name}>
                  <Link 
                    to={link.href}
                    className="text-gray-600 hover:text-gembank-gold transition-colors text-sm"
                  >
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Resources Links */}
          <div>
            <h3 className="font-bold text-gray-900 mb-4">Resources</h3>
            <ul className="space-y-3">
              {footerLinks.resources.map((link) => (
                <li key={link.name}>
                  <Link 
                    to={link.href}
                    className="text-gray-600 hover:text-gembank-gold transition-colors text-sm"
                  >
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Legal Links */}
          <div>
            <h3 className="font-bold text-gray-900 mb-4">Legal</h3>
            <ul className="space-y-3">
              {footerLinks.legal.map((link) => (
                <li key={link.name}>
                  <Link 
                    to={link.href}
                    className="text-gray-600 hover:text-gembank-gold transition-colors text-sm"
                  >
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Newsletter Subscription */}
        <div className="mt-12 pt-12 border-t border-gray-200">
          <div className="max-w-md">
            <h3 className="font-bold text-gray-900 mb-3">Stay Updated</h3>
            <p className="text-gray-600 text-sm mb-4">
              Get the latest features, tips, and industry insights delivered to your inbox.
            </p>
            <div className="flex gap-2">
              <input
                type="email"
                placeholder="your@email.com"
                className="flex-1 px-4 py-2 bg-white border border-gray-300 rounded-xl text-gray-800 placeholder-gray-400 focus:outline-none focus:border-gembank-gold transition-all"
              />
              <button className="px-6 py-2 bg-gradient-to-r from-gembank-gold-light to-gembank-gold text-gembank-charcoal font-semibold rounded-xl transition-all shadow-lg shadow-gembank-gold/20 hover:shadow-xl hover:shadow-gembank-gold/40 transform hover:-translate-y-0.5">
                Subscribe
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t border-gray-200">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            
            {/* Copyright */}
            <div className="text-gray-500 text-sm">
              © {new Date().getFullYear()} GEMBank Technologies Pvt. Ltd. All rights reserved.
            </div>

            {/* Social Links */}
            <div className="flex items-center gap-4">
              {socialLinks.map((social) => (
                <a
                  key={social.name}
                  href={social.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-10 h-10 bg-white hover:bg-gembank-gold/10 border border-gray-200 hover:border-gembank-gold/50 rounded-xl flex items-center justify-center text-xl transition-all transform hover:scale-110"
                  aria-label={social.name}
                >
                  <social.Icon className="w-5 h-5 text-gray-700" />
                </a>
              ))}
            </div>

            {/* Language Selector */}
            <div className="flex items-center gap-2 text-sm">
              <Globe className="w-4 h-4 text-gray-600" />
              <select className="bg-gray-100 border border-gray-300 rounded-xl px-3 py-1 text-gray-600 focus:outline-none focus:border-gembank-gold cursor-pointer">
                <option value="en">English</option>
                <option value="hi">हिंदी</option>
                <option value="gu">ગુજરાતી</option>
                <option value="mr">मराठी</option>
              </select>
            </div>
          </div>
        </div>
      </div>

      {/* Disclaimer */}
      <div className="bg-gray-200 border-t border-gray-300">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <p className="text-gray-500 text-xs text-center leading-relaxed">
            <strong>Disclaimer:</strong> GEMBank is a fintech platform partnered with licensed banking institutions. 
            Banking services are provided by our partner banks. Deposits are insured by DICGC up to ₹5 lakhs per account. 
            Investment products are subject to market risks. Please read all scheme-related documents carefully.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;