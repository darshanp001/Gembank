import { useState } from 'react';
import { submitLOI } from '../../services/loi.service';
import { Building2, User, BarChart3, Landmark, ClipboardCheck, ShieldCheck } from "lucide-react";


// ProgressBar Component
const ProgressBar = ({ currentStep, totalSteps }) => {
  const progress = ((currentStep + 1) / totalSteps) * 100;

  return (
    <div className="w-full bg-gembank-gray-200 rounded-full h-2 mb-8">
      <div
        className="bg-gradient-to-r from-gembank-gold to-gembank-gold-dark h-2 rounded-full transition-all duration-500 ease-out"
        style={{ width: `${progress}%` }}
      />
    </div>
  );
};

// FormStepper Component
const FormStepper = ({ steps, currentStep }) => {
  return (
    <div className="flex justify-between items-center mb-8 overflow-x-auto pb-4">
      {steps.map((step, index) => {
        const isActive = index === currentStep;
        const isCompleted = index < currentStep;

        return (
          <div key={index} className="flex items-center flex-shrink-0">
            <div className="flex flex-col items-center">
              <div
                className={`
                  w-12 h-12 rounded-full flex items-center justify-center text-lg font-semibold transition-all duration-300
                  ${isCompleted ? 'bg-gembank-green text-white' : ''}
                  ${isActive ? 'bg-gembank-gold text-gembank-charcoal scale-110 shadow-gold' : ''}
                  ${!isActive && !isCompleted ? 'bg-gembank-gray-300 text-gembank-gray-800' : ''}
                `}
              >
                {isCompleted ? (
                  <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                  </svg>
                ) : (
                  step.icon
                )}
              </div>
              <div
                className={`
                  mt-2 text-xs font-medium text-center whitespace-nowrap
                  ${isActive ? 'text-gembank-gold' : 'text-gembank-gray-800'}
                `}
              >
                {step.title}
              </div>
            </div>

            {index < steps.length - 1 && (
              <div
                className={`
                  w-16 h-0.5 mx-2 transition-all duration-300
                  ${isCompleted ? 'bg-gembank-green' : 'bg-gembank-gray-300'}
                `}
              />
            )}
          </div>
        );
      })}
    </div>
  );
};

const LOIForm = () => {
  const [currentStep, setCurrentStep] = useState(0);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formData, setFormData] = useState({
    // Step 1: Business Information
    businessName: '',
    gstin: '',
    yearEstablished: '',
    businessType: '', // retail/wholesale/manufacturing
    
    // Step 2: Contact Information
    ownerName: '',
    designation: '',
    email: '',
    phone: '',
    alternatePhone: '',
    
    // Step 3: Business Metrics
    annualTurnover: '',
    goldInventoryValue: '',
    averageMonthlyTransactions: '',
    primarySuppliers: '',
    
    // Step 4: Banking & Operations
    currentBankingPartner: '',
    painPoints: [],
    softwareCurrentlyUsing: '',
    
    // Step 5: Interest & Requirements
    featuresInterested: [],
    expectedGoLiveDate: '',
    teamSize: '',
    branchCount: '',
    
    // Step 6: Compliance
    panCard: '',
    hasFSSAILicense: false,
    hasGSTCompliance: false,
    hasHallmarkingCertification: false,
    
    // Additional Info
    referralSource: '',
    comments: ''
  });
  const steps = [
    { title: 'Business Info', icon: <Building2 className="w-6 h-6" /> },
    { title: 'Contact Details', icon: <User className="w-6 h-6" /> },
    { title: 'Business Metrics', icon: <BarChart3 className="w-6 h-6" /> },
    { title: 'Banking', icon: <Landmark className="w-6 h-6" /> },
    { title: 'Requirements', icon: <ClipboardCheck className="w-6 h-6" /> },
    { title: 'Compliance', icon: <ShieldCheck className="w-6 h-6" /> }
  ];
  const handleInputChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleArrayInput = (field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: prev[field].includes(value)
        ? prev[field].filter(item => item !== value)
        : [...prev[field], value]
    }));
  };

  const validateStep = (step) => {
    switch(step) {
      case 0:
        return formData.businessName && formData.yearEstablished && formData.businessType;
      case 1:
        return formData.ownerName && formData.email && formData.phone;
      case 2:
        return formData.annualTurnover && formData.goldInventoryValue;
      case 3:
        return formData.currentBankingPartner && formData.painPoints.length > 0;
      case 4:
        return formData.featuresInterested.length > 0 && formData.expectedGoLiveDate;
      case 5:
        return formData.panCard && formData.hasGSTCompliance;
      default:
        return true;
    }
  };

  const handleNext = () => {
    if (validateStep(currentStep)) {
      setCurrentStep(prev => Math.min(prev + 1, steps.length - 1));
    }
  };

  const handlePrevious = () => {
    setCurrentStep(prev => Math.max(prev - 1, 0));
  };

  const handleSubmit = async () => {
    if (!validateStep(currentStep)) return;

    setIsSubmitting(true);
    try {
      const response = await submitLOI(formData);
      // Navigate to success page with PDF download link
      window.location.href = `/loi/success?pdf=${response.pdfUrl}`;
    } catch (error) {
      alert('Submission failed. Please try again.');
      console.error(error);
    } finally {
      setIsSubmitting(false);
    }
  };

  const renderStepContent = () => {
    switch(currentStep) {
      case 0:
        return (
          <div className="space-y-4">
            <h3 className="text-xl font-semibold text-gembank-charcoal mb-4">Business Information</h3>
            
            <div>
              <label className="block text-sm font-medium text-gembank-gray-800 mb-2">
                Business Name <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                value={formData.businessName}
                onChange={(e) => handleInputChange('businessName', e.target.value)}
                className="w-full px-4 py-3 border border-gembank-gray-300 rounded-lg focus:ring-2 focus:ring-gembank-gold focus:border-transparent"
                placeholder="Enter your business name"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gembank-gray-800 mb-2">
                GSTIN (Optional)
              </label>
              <input
                type="text"
                value={formData.gstin}
                onChange={(e) => handleInputChange('gstin', e.target.value)}
                className="w-full px-4 py-3 border border-gembank-gray-300 rounded-lg focus:ring-2 focus:ring-gembank-gold focus:border-transparent"
                placeholder="22AAAAA0000A1Z5"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gembank-gray-800 mb-2">
                  Year Established <span className="text-red-500">*</span>
                </label>
                <input
                  type="number"
                  value={formData.yearEstablished}
                  onChange={(e) => handleInputChange('yearEstablished', e.target.value)}
                  className="w-full px-4 py-3 border border-gembank-gray-300 rounded-lg focus:ring-2 focus:ring-gembank-gold focus:border-transparent"
                  placeholder="2010"
                  min="1900"
                  max={new Date().getFullYear()}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gembank-gray-800 mb-2">
                  Business Type <span className="text-red-500">*</span>
                </label>
                <select
                  value={formData.businessType}
                  onChange={(e) => handleInputChange('businessType', e.target.value)}
                  className="w-full px-4 py-3 border border-gembank-gray-300 rounded-lg focus:ring-2 focus:ring-gembank-gold focus:border-transparent"
                >
                  <option value="">Select type</option>
                  <option value="retail">Retail</option>
                  <option value="wholesale">Wholesale</option>
                  <option value="manufacturing">Manufacturing</option>
                  <option value="mixed">Mixed Operations</option>
                </select>
              </div>
            </div>
          </div>
        );

      case 1:
        return (
          <div className="space-y-4">
            <h3 className="text-xl font-semibold text-gembank-charcoal mb-4">Contact Information</h3>
            
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gembank-gray-800 mb-2">
                  Owner/Director Name <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  value={formData.ownerName}
                  onChange={(e) => handleInputChange('ownerName', e.target.value)}
                  className="w-full px-4 py-3 border border-gembank-gray-300 rounded-lg focus:ring-2 focus:ring-gembank-gold focus:border-transparent"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gembank-gray-800 mb-2">
                  Designation
                </label>
                <input
                  type="text"
                  value={formData.designation}
                  onChange={(e) => handleInputChange('designation', e.target.value)}
                  className="w-full px-4 py-3 border border-gembank-gray-300 rounded-lg focus:ring-2 focus:ring-gembank-gold focus:border-transparent"
                  placeholder="e.g., Managing Director"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gembank-gray-800 mb-2">
                Business Email <span className="text-red-500">*</span>
              </label>
              <input
                type="email"
                value={formData.email}
                onChange={(e) => handleInputChange('email', e.target.value)}
                className="w-full px-4 py-3 border border-gembank-gray-300 rounded-lg focus:ring-2 focus:ring-gembank-gold focus:border-transparent"
                placeholder="contact@business.com"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gembank-gray-800 mb-2">
                  Primary Phone <span className="text-red-500">*</span>
                </label>
                <input
                  type="tel"
                  value={formData.phone}
                  onChange={(e) => handleInputChange('phone', e.target.value)}
                  className="w-full px-4 py-3 border border-gembank-gray-300 rounded-lg focus:ring-2 focus:ring-gembank-gold focus:border-transparent"
                  placeholder="+91 98765 43210"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gembank-gray-800 mb-2">
                  Alternate Phone
                </label>
                <input
                  type="tel"
                  value={formData.alternatePhone}
                  onChange={(e) => handleInputChange('alternatePhone', e.target.value)}
                  className="w-full px-4 py-3 border border-gembank-gray-300 rounded-lg focus:ring-2 focus:ring-gembank-gold focus:border-transparent"
                  placeholder="+91 98765 43211"
                />
              </div>
            </div>
          </div>
        );

      case 2:
        return (
          <div className="space-y-4">
            <h3 className="text-xl font-semibold text-gembank-charcoal mb-4">Business Metrics</h3>
            
            <div>
              <label className="block text-sm font-medium text-gembank-gray-800 mb-2">
                Annual Turnover (₹) <span className="text-red-500">*</span>
              </label>
              <select
                value={formData.annualTurnover}
                onChange={(e) => handleInputChange('annualTurnover', e.target.value)}
                className="w-full px-4 py-3 border border-gembank-gray-300 rounded-lg focus:ring-2 focus:ring-gembank-gold focus:border-transparent"
              >
                <option value="">Select range</option>
                <option value="below-1cr">Below ₹1 Crore</option>
                <option value="1cr-5cr">₹1 - 5 Crore</option>
                <option value="5cr-10cr">₹5 - 10 Crore</option>
                <option value="10cr-25cr">₹10 - 25 Crore</option>
                <option value="25cr-50cr">₹25 - 50 Crore</option>
                <option value="above-50cr">Above ₹50 Crore</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gembank-gray-800 mb-2">
                Gold Inventory Value (₹) <span className="text-red-500">*</span>
              </label>
              <select
                value={formData.goldInventoryValue}
                onChange={(e) => handleInputChange('goldInventoryValue', e.target.value)}
                className="w-full px-4 py-3 border border-gembank-gray-300 rounded-lg focus:ring-2 focus:ring-gembank-gold focus:border-transparent"
              >
                <option value="">Select range</option>
                <option value="below-50l">Below ₹50 Lakh</option>
                <option value="50l-1cr">₹50 Lakh - 1 Crore</option>
                <option value="1cr-5cr">₹1 - 5 Crore</option>
                <option value="5cr-10cr">₹5 - 10 Crore</option>
                <option value="above-10cr">Above ₹10 Crore</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gembank-gray-800 mb-2">
                Average Monthly Transactions
              </label>
              <input
                type="number"
                value={formData.averageMonthlyTransactions}
                onChange={(e) => handleInputChange('averageMonthlyTransactions', e.target.value)}
                className="w-full px-4 py-3 border border-gembank-gray-300 rounded-lg focus:ring-2 focus:ring-gembank-gold focus:border-transparent"
                placeholder="e.g., 150"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gembank-gray-800 mb-2">
                Primary Suppliers (comma-separated)
              </label>
              <textarea
                value={formData.primarySuppliers}
                onChange={(e) => handleInputChange('primarySuppliers', e.target.value)}
                className="w-full px-4 py-3 border border-gembank-gray-300 rounded-lg focus:ring-2 focus:ring-gembank-gold focus:border-transparent"
                rows="3"
                placeholder="e.g., Tanishq Wholesale, Mumbai Gold Ltd"
              />
            </div>
          </div>
        );

      case 3:
        return (
          <div className="space-y-4">
            <h3 className="text-xl font-semibold text-gembank-charcoal mb-4">Banking & Operations</h3>
            
            <div>
              <label className="block text-sm font-medium text-gembank-gray-800 mb-2">
                Current Banking Partner <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                value={formData.currentBankingPartner}
                onChange={(e) => handleInputChange('currentBankingPartner', e.target.value)}
                className="w-full px-4 py-3 border border-gembank-gray-300 rounded-lg focus:ring-2 focus:ring-gembank-gold focus:border-transparent"
                placeholder="e.g., HDFC Bank, ICICI Bank"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gembank-gray-800 mb-2">
                Current Pain Points <span className="text-red-500">*</span> (Select all that apply)
              </label>
              <div className="space-y-2">
                {[
                  'Slow payment processing',
                  'High transaction fees',
                  'No gold inventory tracking',
                  'Poor customer support',
                  'Limited business insights',
                  'Complex compliance management',
                  'No digital invoicing',
                  'Manual record keeping'
                ].map(pain => (
                  <label key={pain} className="flex items-center space-x-3 p-3 border border-gembank-gray-300 rounded-lg hover:bg-gembank-gray-50 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={formData.painPoints.includes(pain)}
                      onChange={() => handleArrayInput('painPoints', pain)}
                      className="w-4 h-4 text-gembank-gold focus:ring-gembank-gold border-gembank-gray-300 rounded"
                    />
                    <span className="text-sm text-gembank-gray-800">{pain}</span>
                  </label>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gembank-gray-800 mb-2">
                Software Currently Using
              </label>
              <input
                type="text"
                value={formData.softwareCurrentlyUsing}
                onChange={(e) => handleInputChange('softwareCurrentlyUsing', e.target.value)}
                className="w-full px-4 py-3 border border-gembank-gray-300 rounded-lg focus:ring-2 focus:ring-gembank-gold focus:border-transparent"
                placeholder="e.g., Tally, Excel, Custom ERP"
              />
            </div>
          </div>
        );

      case 4:
        return (
          <div className="space-y-4">
            <h3 className="text-xl font-semibold text-gembank-charcoal mb-4">Requirements</h3>
            
            <div>
              <label className="block text-sm font-medium text-gembank-gray-800 mb-2">
                Features Interested In <span className="text-red-500">*</span> (Select all that apply)
              </label>
              <div className="grid grid-cols-2 gap-3">
                {[
                  'Gold rate tracking',
                  'Inventory management',
                  'B2B payments',
                  'Digital invoicing',
                  'Compliance tracking',
                  'Customer management',
                  'Analytics dashboard',
                  'Multi-branch support'
                ].map(feature => (
                  <label key={feature} className="flex items-center space-x-3 p-3 border border-gembank-gray-300 rounded-lg hover:bg-gembank-gray-50 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={formData.featuresInterested.includes(feature)}
                      onChange={() => handleArrayInput('featuresInterested', feature)}
                      className="w-4 h-4 text-gembank-gold focus:ring-gembank-gold border-gembank-gray-300 rounded"
                    />
                    <span className="text-sm text-gembank-gray-800">{feature}</span>
                  </label>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gembank-gray-800 mb-2">
                  Expected Go-Live Date <span className="text-red-500">*</span>
                </label>
                <input
                  type="date"
                  value={formData.expectedGoLiveDate}
                  onChange={(e) => handleInputChange('expectedGoLiveDate', e.target.value)}
                  className="w-full px-4 py-3 border border-gembank-gray-300 rounded-lg focus:ring-2 focus:ring-gembank-gold focus:border-transparent"
                  min={new Date().toISOString().split('T')[0]}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gembank-gray-800 mb-2">
                  Team Size
                </label>
                <input
                  type="number"
                  value={formData.teamSize}
                  onChange={(e) => handleInputChange('teamSize', e.target.value)}
                  className="w-full px-4 py-3 border border-gembank-gray-300 rounded-lg focus:ring-2 focus:ring-gembank-gold focus:border-transparent"
                  placeholder="e.g., 10"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gembank-gray-800 mb-2">
                Number of Branches/Outlets
              </label>
              <input
                type="number"
                value={formData.branchCount}
                onChange={(e) => handleInputChange('branchCount', e.target.value)}
                className="w-full px-4 py-3 border border-gembank-gray-300 rounded-lg focus:ring-2 focus:ring-gembank-gold focus:border-transparent"
                placeholder="e.g., 3"
              />
            </div>
          </div>
        );

      case 5:
        return (
          <div className="space-y-4">
            <h3 className="text-xl font-semibold text-gembank-charcoal mb-4">Compliance & Additional Info</h3>
            
            <div>
              <label className="block text-sm font-medium text-gembank-gray-800 mb-2">
                PAN Card Number <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                value={formData.panCard}
                onChange={(e) => handleInputChange('panCard', e.target.value.toUpperCase())}
                className="w-full px-4 py-3 border border-gembank-gray-300 rounded-lg focus:ring-2 focus:ring-gembank-gold focus:border-transparent"
                placeholder="ABCDE1234F"
                maxLength="10"
              />
            </div>

            <div className="space-y-3">
              <label className="block text-sm font-medium text-gembank-gray-800 mb-2">
                Certifications & Compliance <span className="text-red-500">*</span>
              </label>
              
              <label className="flex items-center space-x-3 p-4 border border-gembank-gray-300 rounded-lg hover:bg-gembank-gray-50 cursor-pointer">
                <input
                  type="checkbox"
                  checked={formData.hasGSTCompliance}
                  onChange={(e) => handleInputChange('hasGSTCompliance', e.target.checked)}
                  className="w-5 h-5 text-gembank-gold focus:ring-gembank-gold border-gembank-gray-300 rounded"
                />
                <span className="text-sm font-medium text-gembank-gray-800">GST Compliant</span>
              </label>

              <label className="flex items-center space-x-3 p-4 border border-gembank-gray-300 rounded-lg hover:bg-gembank-gray-50 cursor-pointer">
                <input
                  type="checkbox"
                  checked={formData.hasHallmarkingCertification}
                  onChange={(e) => handleInputChange('hasHallmarkingCertification', e.target.checked)}
                  className="w-5 h-5 text-gembank-gold focus:ring-gembank-gold border-gembank-gray-300 rounded"
                />
                <span className="text-sm font-medium text-gembank-gray-800">BIS Hallmarking Certification</span>
              </label>

              <label className="flex items-center space-x-3 p-4 border border-gembank-gray-300 rounded-lg hover:bg-gembank-gray-50 cursor-pointer">
                <input
                  type="checkbox"
                  checked={formData.hasFSSAILicense}
                  onChange={(e) => handleInputChange('hasFSSAILicense', e.target.checked)}
                  className="w-5 h-5 text-gembank-gold focus:ring-gembank-gold border-gembank-gray-300 rounded"
                />
                <span className="text-sm font-medium text-gembank-gray-800">FSSAI License (if applicable)</span>
              </label>
            </div>

            <div>
              <label className="block text-sm font-medium text-gembank-gray-800 mb-2">
                How did you hear about us?
              </label>
              <select
                value={formData.referralSource}
                onChange={(e) => handleInputChange('referralSource', e.target.value)}
                className="w-full px-4 py-3 border border-gembank-gray-300 rounded-lg focus:ring-2 focus:ring-gembank-gold focus:border-transparent"
              >
                <option value="">Select source</option>
                <option value="google">Google Search</option>
                <option value="social-media">Social Media</option>
                <option value="referral">Friend/Colleague Referral</option>
                <option value="trade-show">Trade Show/Event</option>
                <option value="advertisement">Advertisement</option>
                <option value="other">Other</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gembank-gray-800 mb-2">
                Additional Comments
              </label>
              <textarea
                value={formData.comments}
                onChange={(e) => handleInputChange('comments', e.target.value)}
                className="w-full px-4 py-3 border border-gembank-gray-300 rounded-lg focus:ring-2 focus:ring-gembank-gold focus:border-transparent"
                rows="4"
                placeholder="Any specific requirements or questions?"
              />
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gembank-gray-50 to-white py-12 px-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-3xl font-display font-bold text-gembank-charcoal mb-2">
            Letter of Interest - Pilot Program
          </h1>
          <p className="text-gembank-gray-800">
            Help us understand your business needs • Takes 5-7 minutes
          </p>
        </div>

        {/* Progress Bar */}
        <ProgressBar currentStep={currentStep} totalSteps={steps.length} />

        {/* Stepper */}
        <FormStepper steps={steps} currentStep={currentStep} />

        {/* Form Content */}
        <div className="bg-white rounded-xl shadow-card p-8 mb-6">
          {renderStepContent()}
        </div>

        {/* Navigation Buttons */}
        <div className="flex justify-between items-center">
          <button
            onClick={handlePrevious}
            disabled={currentStep === 0}
            className="px-6 py-3 border-2 border-gembank-gray-300 text-gembank-gray-800 rounded-lg font-medium hover:bg-gembank-gray-50 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
          >
            ← Previous
          </button>

          <div className="text-sm text-gembank-gray-800">
            Step {currentStep + 1} of {steps.length}
          </div>

          {currentStep < steps.length - 1 ? (
            <button
              onClick={handleNext}
              disabled={!validateStep(currentStep)}
              className="px-6 py-3 bg-gembank-gold text-gembank-charcoal rounded-lg font-semibold hover:bg-gembank-gold-dark disabled:opacity-50 disabled:cursor-not-allowed transition-all shadow-gold"
            >
              Next →
            </button>
          ) : (
            <button
              onClick={handleSubmit}
              disabled={!validateStep(currentStep) || isSubmitting}
              className="px-8 py-3 bg-gembank-gold text-gembank-charcoal rounded-lg font-semibold hover:bg-gembank-gold-dark disabled:opacity-50 disabled:cursor-not-allowed transition-all shadow-gold flex items-center gap-2"
            >
              {isSubmitting ? (
                <>
                  <svg className="animate-spin h-5 w-5" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                  </svg>
                  Submitting...
                </>
              ) : (
                <>
                  Submit LOI
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                </>
              )}
            </button>
          )}
        </div>

        {/* Help Text */}
        <div className="mt-6 text-center text-sm text-gembank-gray-800">
          Need help? <a href="mailto:support@gembank.com" className="text-gembank-gold hover:underline">Contact our team</a>
        </div>
      </div>
    </div>
  );
};

export default LOIForm;