import { useState } from "react";
import { useNavigate } from "react-router-dom";
import Button from "../common/Button";
import heroMockup from "../../assets/images/hero-mockup.png";
import { ArrowRight, CheckCircle, Lock, Award } from "lucide-react";

const HeroSection = () => {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [showMockup, setShowMockup] = useState(true);

  const handleEarlyAccess = () => {
    navigate("/signup", { state: { email } });
  };

  const handleBookPilot = () => {
    navigate("/loi");
  };

  return (
    <section className="relative bg-gray-50 text-gray-800 min-h-screen flex items-center py-16 lg:py-24 overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0">
        <div
          className="absolute inset-0"
          style={{
            backgroundImage: `radial-gradient(circle at 1px 1px, rgba(0, 0, 0, 0.04) 1px, transparent 0)`,
            backgroundSize: "30px 30px",
          }}
        />
      </div>

      <div className="container mx-auto px-5 sm:px-8 relative z-10">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Left Column */}
          <div className="animate-fade-in-down text-center lg:text-left">
            <div className="inline-block mb-4">
              <span className="px-4 py-2 bg-yellow-200/80 border border-yellow-300 rounded-full text-yellow-900 text-sm font-medium shadow-sm ring-1 ring-yellow-300/40">
                ✨ Built Exclusively for Indian Jewellers
              </span>
            </div>

            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-display font-bold leading-tight mb-6 tracking-tight">
              The Premier Neobank for{" "}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#C9A73A] via-[#E3C35F] to-[#B88F21]">
                Indian Jewellers
              </span>
            </h1>

            <p className="text-lg sm:text-xl text-gray-700 mb-8 leading-relaxed max-w-xl mx-auto lg:mx-0">
              Manage inventory, track gold rates, process B2B payments, and maintain compliance—all in one intelligent platform.{" "}
              <strong className="text-gembank-gold">Trusted by 200+ pilot jewellers.</strong>
            </p>

            {/* Value Props */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-10">
              <div className="text-center p-4 bg-white backdrop-blur-sm rounded-xl border border-gray-200 hover:border-gembank-gold/50 hover:shadow-md transition-all">
                <div className="text-2xl font-bold text-gembank-gold">₹500Cr+</div>
                <div className="text-xs text-gray-500 mt-1">Gold Value Tracked</div>
              </div>
              <div className="text-center p-4 bg-white backdrop-blur-sm rounded-xl border border-gray-200 hover:border-gembank-gold/50 hover:shadow-md transition-all">
                <div className="text-2xl font-bold text-gembank-green">12.5g</div>
                <div className="text-xs text-gray-500 mt-1">Avg. Precision</div>
              </div>
              <div className="text-center p-4 bg-white backdrop-blur-sm rounded-xl border border-gray-200 hover:border-gembank-gold/50 hover:shadow-md transition-all">
                <div className="text-2xl font-bold text-gembank-purple">24/7</div>
                <div className="text-xs text-gray-500 mt-1">Live Support</div>
              </div>
            </div>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 mb-6 justify-center lg:justify-start">
              <Button variant="primary" size="lg" onClick={handleEarlyAccess}>
                Get Early Access
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>

              <Button
                variant="outline"
                size="lg"
                onClick={handleBookPilot}
                className="border-gray-400 text-gray-800 hover:bg-gray-50 hover:border-gray-500"
              >
                Book a Pilot Program
              </Button>
            </div>

            {/* Email Input */}
            <div className="flex items-center gap-3 p-1 bg-white backdrop-blur-sm rounded-xl border border-gray-300 max-w-md mx-auto lg:mx-0 shadow-sm">
              <input
                type="email"
                placeholder="your@business.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="flex-1 bg-transparent text-gray-800 placeholder-gray-500 px-4 py-2 focus:outline-none"
              />
              <Button variant="primary" size="sm" onClick={handleEarlyAccess}>
                Join Waitlist
              </Button>
            </div>

            {/* Trust Indicators */}
            <div className="flex flex-wrap justify-center lg:justify-start gap-4 mt-8">
              <div className="flex items-center gap-2 px-3 py-1.5 bg-green-100 border border-green-200 rounded-full text-xs text-green-800 font-medium">
                <CheckCircle className="w-4 h-4 text-green-600" />
                <span>Fully RBI Compliant</span>
              </div>
              <div className="flex items-center gap-2 px-3 py-1.5 bg-blue-100 border border-blue-200 rounded-full text-xs text-blue-800 font-medium">
                <Lock className="w-4 h-4 text-blue-600" />
                <span>Bank-Grade Encryption</span>
              </div>
              <div className="flex items-center gap-2 px-3 py-1.5 bg-indigo-100 border border-indigo-200 rounded-full text-xs text-indigo-800 font-medium">
                  <Award className="w-4 h-4 text-indigo-600" />
                <span>ISO 27001 Certified</span>
              </div>
            </div>
          </div>

          {/* Right Column */}
          <div className="relative flex justify-center animate-slide-up-fade">
            {showMockup && (
              <div className="relative z-10">
                <img
                  src={heroMockup}
                  alt="GEMBank Mobile App Interface"
                  className="w-full max-w-sm sm:max-w-md mx-auto drop-shadow-2xl rounded-3xl transition-transform duration-500 hover:scale-105"
                  onError={() => setShowMockup(false)}
                />
              </div>
            )}

            {/* Floating Cards */}
            <div className="absolute -top-4 -left-6 sm:top-2 sm:-left-8 bg-white/90 backdrop-blur-md p-4 rounded-2xl shadow-xl max-w-[200px] border border-gray-200/70">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-gembank-green/15 rounded-xl flex items-center justify-center ring-1 ring-green-500/20">
                  <span className="text-gembank-green text-xl">📈</span>
                </div>
                <div>
                  <div className="text-[11px] uppercase tracking-wide text-gray-500">Gold Rate</div>
                  <div className="text-base font-bold text-gray-900">₹6,245/g</div>
                </div>
              </div>
            </div>

            {/* <div className="absolute -bottom-4 -right-6 sm:bottom-2 sm:-right-8 bg-gradient-to-br from-white/95 to-gembank-gold/10 backdrop-blur-md p-4 rounded-2xl shadow-xl max-w-[220px] border border-gembank-gold/30">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-gembank-purple/15 rounded-xl flex items-center justify-center ring-1 ring-purple-500/20">
                  <span className="text-gembank-purple text-xl">💳</span>
                </div>
                <div>
                  <div className="text-[11px] uppercase tracking-wide text-gray-500">Quick Payment</div>
                  <div className="text-base font-bold text-gray-900">₹2.5L sent</div>
                </div>
              </div>
            </div> */}
          </div>
        </div>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 hidden lg:block">
        <div className="w-6 h-10 border-2 border-gray-400/50 rounded-full flex justify-center items-start p-1">
          <div className="w-1.5 h-1.5 bg-gembank-gold rounded-full animate-scroll-down"></div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
