// TrustStrip.jsx
export const TrustStrip = () => {
  const trustItems = [
    { icon: '🏦', text: 'RBI Compliant' },
    { icon: '🔒', text: 'Bank-Grade Security' },
    { icon: '✅', text: 'ISO 27001 Certified' },
    { icon: '💳', text: 'DICGC Insured' },
    { icon: '⚡', text: '200+ Pilot Customers' }
  ];

  return (
    <section className="py-12 bg-white border-y border-gembank-gray-200">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <p className="text-center text-sm font-semibold text-gembank-gray-800 mb-6 uppercase tracking-wide">
          Trusted by Leading Jewellers Across India
        </p>
        <div className="flex flex-wrap justify-center items-center gap-8">
          {trustItems.map((item, index) => (
            <div 
              key={index}
              className="flex items-center gap-2 text-gembank-gray-800 hover:text-gembank-gold transition-colors"
            >
              <span className="text-2xl">{item.icon}</span>
              <span className="font-medium">{item.text}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default { TrustStrip };