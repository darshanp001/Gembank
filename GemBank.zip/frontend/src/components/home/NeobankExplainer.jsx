import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Button from '../common/Button';

// NeobankExplainer.jsx
export const NeobankExplainer = () => {
  const [activeTab, setActiveTab] = useState('what');

  const tabs = [
    { id: 'what', label: 'What is a Neobank?', icon: '❓' },
    { id: 'how', label: 'How Does It Work?', icon: '⚙️' },
    { id: 'why', label: 'Why GEMBank?', icon: '💎' }
  ];

  const content = {
    what: {
      title: 'Digital Banking for the Modern Jeweller',
      description: 'A neobank is a fully digital bank with no physical branches. GEMBank combines traditional banking services with specialized tools for jewellery businesses.',
      points: [
        {
          icon: '📱',
          title: 'Fully Digital',
          text: 'Open accounts, process payments, and manage inventory from your phone or computer'
        },
        {
          icon: '💰',
          title: 'Lower Costs',
          text: 'No overhead of physical branches means we pass savings to you through zero fees'
        },
        {
          icon: '🎯',
          title: 'Industry-Specific',
          text: 'Built exclusively for jewellers, not generic banking features'
        },
        {
          icon: '⚡',
          title: 'Always Available',
          text: '24/7 access to your accounts, real-time transactions, instant support'
        }
      ]
    },
    how: {
      title: 'Simple, Secure, Seamless',
      description: 'GEMBank partners with licensed banks to offer you all banking services through our specialized platform.',
      points: [
        {
          icon: '🔐',
          title: 'Partner Banking',
          text: 'Your funds are held by RBI-licensed partner banks, fully DICGC insured'
        },
        {
          icon: '💳',
          title: 'Integrated Platform',
          text: 'One dashboard for banking, inventory, invoicing, and compliance'
        },
        {
          icon: '🤖',
          title: 'Smart Automation',
          text: 'AI-powered features like auto gold valuation and compliance tracking'
        },
        {
          icon: '🔄',
          title: 'Real-Time Sync',
          text: 'Instantly sync with Tally, GST portal, and your existing systems'
        }
      ]
    },
    why: {
      title: 'Built by Jewellers, for Jewellers',
      description: 'We understand your unique challenges because we work with 200+ jewellers every day.',
      points: [
        {
          icon: '💎',
          title: 'Gold-Specific Features',
          text: 'Live gold rates, inventory by karat/weight, automatic revaluation'
        },
        {
          icon: '📊',
          title: 'B2B Focused',
          text: 'Supplier payments, wholesale transactions, multi-branch management'
        },
        {
          icon: '✅',
          title: 'Compliance Built-In',
          text: 'GST, hallmarking, BIS - all automated and audit-ready'
        },
        {
          icon: '🤝',
          title: 'Community Network',
          text: 'Connect with verified suppliers, refiners, and other jewellers'
        }
      ]
    }
  };

  const activeContent = content[activeTab];

  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center mb-12">
          <span className="inline-block px-4 py-2 bg-gembank-purple/10 border border-gembank-purple/30 rounded-full text-gembank-purple text-sm font-medium mb-4">
            Learn About GEMBank
          </span>
          <h2 className="text-3xl sm:text-4xl font-display font-bold text-gembank-charcoal mb-4">
            Not Your Traditional Bank
          </h2>
          <p className="text-lg text-gembank-gray-800 max-w-2xl mx-auto">
            Discover how digital banking is revolutionizing the jewellery industry
          </p>
        </div>

        {/* Tab Navigation */}
        <div className="flex flex-col sm:flex-row justify-center gap-3 mb-12">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`px-6 py-3 rounded-lg font-semibold transition-all duration-300 flex items-center justify-center gap-2 ${
                activeTab === tab.id
                  ? 'bg-gembank-gold text-gembank-charcoal shadow-gold'
                  : 'bg-gembank-gray-100 text-gembank-gray-800 hover:bg-gembank-gray-200'
              }`}
            >
              <span className="text-xl">{tab.icon}</span>
              <span>{tab.label}</span>
            </button>
          ))}
        </div>

        {/* Content Area */}
        <div className="max-w-5xl mx-auto">
          <div className="bg-gradient-to-br from-gembank-gray-50 to-white rounded-2xl p-8 md:p-12 border-2 border-gembank-gray-200">
            
            <h3 className="text-2xl font-bold text-gembank-charcoal mb-3">
              {activeContent.title}
            </h3>
            <p className="text-gembank-gray-800 mb-8 text-lg">
              {activeContent.description}
            </p>

            <div className="grid md:grid-cols-2 gap-6">
              {activeContent.points.map((point, index) => (
                <div 
                  key={index}
                  className="bg-white rounded-xl p-6 border border-gembank-gray-200 hover:border-gembank-gold hover:shadow-gold transition-all duration-300"
                >
                  <div className="text-4xl mb-4">{point.icon}</div>
                  <h4 className="font-bold text-gembank-charcoal mb-2">
                    {point.title}
                  </h4>
                  <p className="text-sm text-gembank-gray-800 leading-relaxed">
                    {point.text}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Quick Stats */}
        <div className="mt-12 grid grid-cols-2 md:grid-cols-4 gap-6 max-w-4xl mx-auto">
          <div className="text-center">
            <div className="text-3xl font-bold text-gembank-gold mb-1">100%</div>
            <div className="text-sm text-gembank-gray-800">Digital</div>
          </div>
          <div className="text-center">
            <div className="text-3xl font-bold text-gembank-green mb-1">0₹</div>
            <div className="text-sm text-gembank-gray-800">Setup Fee</div>
          </div>
          <div className="text-center">
            <div className="text-3xl font-bold text-gembank-purple mb-1">24/7</div>
            <div className="text-sm text-gembank-gray-800">Available</div>
          </div>
          <div className="text-center">
            <div className="text-3xl font-bold text-gembank-blue mb-1">5 min</div>
            <div className="text-sm text-gembank-gray-800">Sign Up</div>
          </div>
        </div>
      </div>
    </section>
  );
};


export default { NeobankExplainer  };