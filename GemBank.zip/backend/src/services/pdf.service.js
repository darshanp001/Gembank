const puppeteer = require('puppeteer');
const fs = require('fs').promises;
const path = require('path');

/**
 * Generate LOI PDF using Puppeteer
 * @param {Object} data - LOI form data
 * @returns {Promise<Buffer>} PDF buffer
 */
exports.generateLOIPDF = async (data) => {
  let browser;
  
  try {
    browser = await puppeteer.launch({
      headless: true,
      args: ['--no-sandbox', '--disable-setuid-sandbox']
    });

    const page = await browser.newPage();
    
    // Generate HTML content
    const htmlContent = generateLOIHTML(data);
    
    await page.setContent(htmlContent, {
      waitUntil: 'networkidle0'
    });

    // Generate PDF
    const pdfBuffer = await page.pdf({
      format: 'A4',
      printBackground: true,
      margin: {
        top: '20mm',
        right: '15mm',
        bottom: '20mm',
        left: '15mm'
      }
    });

    return pdfBuffer;

  } catch (error) {
    console.error('PDF Generation Error:', error);
    throw new Error('Failed to generate PDF');
  } finally {
    if (browser) {
      await browser.close();
    }
  }
};

/**
 * Generate HTML template for LOI PDF
 * @param {Object} data - LOI form data
 * @returns {string} HTML content
 */
function generateLOIHTML(data) {
  const {
    loiReference,
    submittedDate,
    businessName,
    gstin,
    yearEstablished,
    businessType,
    ownerName,
    designation,
    email,
    phone,
    alternatePhone,
    annualTurnover,
    goldInventoryValue,
    averageMonthlyTransactions,
    primarySuppliers,
    currentBankingPartner,
    painPoints,
    softwareCurrentlyUsing,
    featuresInterested,
    expectedGoLiveDate,
    teamSize,
    branchCount,
    panCard,
    hasFSSAILicense,
    hasGSTCompliance,
    hasHallmarkingCertification,
    referralSource,
    comments
  } = data;

  return `
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Letter of Interest - ${loiReference}</title>
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    body {
      font-family: 'Arial', sans-serif;
      font-size: 11pt;
      line-height: 1.6;
      color: #333;
    }

    .header {
      background: linear-gradient(135deg, #2C3E50 0%, #1a1a2e 100%);
      color: white;
      padding: 30px;
      margin-bottom: 30px;
      border-radius: 8px;
    }

    .logo-section {
      display: flex;
      align-items: center;
      gap: 15px;
      margin-bottom: 15px;
    }

    .logo {
      width: 50px;
      height: 50px;
      background: linear-gradient(135deg, #D4AF37, #B8941F);
      border-radius: 8px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 28px;
    }

    .company-name {
      font-size: 28px;
      font-weight: bold;
    }

    .gold-text {
      color: #D4AF37;
    }

    .header-info {
      display: flex;
      justify-content: space-between;
      margin-top: 15px;
      font-size: 10pt;
    }

    .section {
      margin-bottom: 25px;
      page-break-inside: avoid;
    }

    .section-title {
      background-color: #2C3E50;
      color: white;
      padding: 10px 15px;
      font-size: 13pt;
      font-weight: bold;
      margin-bottom: 15px;
      border-radius: 4px;
    }

    .field-group {
      display: grid;
      grid-template-columns: repeat(2, 1fr);
      gap: 15px;
      margin-bottom: 10px;
    }

    .field {
      padding: 10px;
      border: 1px solid #e0e0e0;
      border-radius: 4px;
      background-color: #f9f9f9;
    }

    .field-label {
      font-weight: bold;
      color: #555;
      font-size: 9pt;
      text-transform: uppercase;
      margin-bottom: 5px;
    }

    .field-value {
      color: #333;
      font-size: 11pt;
    }

    .field-full {
      grid-column: 1 / -1;
    }

    .checkbox-group {
      display: flex;
      flex-wrap: wrap;
      gap: 10px;
      margin-top: 10px;
    }

    .checkbox-item {
      background-color: #f0f0f0;
      padding: 8px 12px;
      border-radius: 4px;
      font-size: 10pt;
    }

    .checkbox-item::before {
      content: "✓ ";
      color: #4CAF50;
      font-weight: bold;
      margin-right: 5px;
    }

    .footer {
      margin-top: 40px;
      padding-top: 20px;
      border-top: 2px solid #D4AF37;
      text-align: center;
      font-size: 9pt;
      color: #666;
    }

    .signature-section {
      margin-top: 50px;
      display: grid;
      grid-template-columns: repeat(2, 1fr);
      gap: 40px;
    }

    .signature-box {
      border-top: 2px solid #333;
      padding-top: 10px;
      text-align: center;
    }

    .declaration {
      background-color: #fff8e1;
      border-left: 4px solid #D4AF37;
      padding: 15px;
      margin: 20px 0;
      font-size: 10pt;
      font-style: italic;
    }

    @media print {
      body {
        print-color-adjust: exact;
        -webkit-print-color-adjust: exact;
      }
    }
  </style>
</head>
<body>
  <!-- Header -->
  <div class="header">
    <div class="logo-section">
      <div class="logo">💎</div>
      <div class="company-name">
        <span class="gold-text">GEM</span>Bank
      </div>
    </div>
    <div style="font-size: 18pt; font-weight: bold; margin-bottom: 10px;">
      LETTER OF INTEREST - PILOT PROGRAM
    </div>
    <div class="header-info">
      <div>
        <strong>Reference:</strong> ${loiReference}
      </div>
      <div>
        <strong>Date:</strong> ${submittedDate}
      </div>
    </div>
  </div>

  <!-- Business Information -->
  <div class="section">
    <div class="section-title">📊 Business Information</div>
    <div class="field-group">
      <div class="field">
        <div class="field-label">Business Name</div>
        <div class="field-value">${businessName}</div>
      </div>
      <div class="field">
        <div class="field-label">Business Type</div>
        <div class="field-value">${formatBusinessType(businessType)}</div>
      </div>
      <div class="field">
        <div class="field-label">Year Established</div>
        <div class="field-value">${yearEstablished}</div>
      </div>
      ${gstin ? `
      <div class="field">
        <div class="field-label">GSTIN</div>
        <div class="field-value">${gstin}</div>
      </div>
      ` : ''}
    </div>
  </div>

  <!-- Contact Information -->
  <div class="section">
    <div class="section-title">👤 Contact Information</div>
    <div class="field-group">
      <div class="field">
        <div class="field-label">Owner/Director Name</div>
        <div class="field-value">${ownerName}</div>
      </div>
      <div class="field">
        <div class="field-label">Designation</div>
        <div class="field-value">${designation || 'N/A'}</div>
      </div>
      <div class="field">
        <div class="field-label">Email</div>
        <div class="field-value">${email}</div>
      </div>
      <div class="field">
        <div class="field-label">Primary Phone</div>
        <div class="field-value">${phone}</div>
      </div>
      ${alternatePhone ? `
      <div class="field">
        <div class="field-label">Alternate Phone</div>
        <div class="field-value">${alternatePhone}</div>
      </div>
      ` : ''}
    </div>
  </div>

  <!-- Business Metrics -->
  <div class="section">
    <div class="section-title">📈 Business Metrics</div>
    <div class="field-group">
      <div class="field">
        <div class="field-label">Annual Turnover</div>
        <div class="field-value">${formatTurnover(annualTurnover)}</div>
      </div>
      <div class="field">
        <div class="field-label">Gold Inventory Value</div>
        <div class="field-value">${formatTurnover(goldInventoryValue)}</div>
      </div>
      <div class="field">
        <div class="field-label">Avg. Monthly Transactions</div>
        <div class="field-value">${averageMonthlyTransactions || 'N/A'}</div>
      </div>
      <div class="field">
        <div class="field-label">Number of Branches</div>
        <div class="field-value">${branchCount || 'N/A'}</div>
      </div>
      ${primarySuppliers ? `
      <div class="field field-full">
        <div class="field-label">Primary Suppliers</div>
        <div class="field-value">${primarySuppliers}</div>
      </div>
      ` : ''}
    </div>
  </div>

  <!-- Banking & Operations -->
  <div class="section">
    <div class="section-title">🏦 Banking & Operations</div>
    <div class="field-group">
      <div class="field">
        <div class="field-label">Current Banking Partner</div>
        <div class="field-value">${currentBankingPartner}</div>
      </div>
      <div class="field">
        <div class="field-label">Software Currently Using</div>
        <div class="field-value">${softwareCurrentlyUsing || 'N/A'}</div>
      </div>
      <div class="field field-full">
        <div class="field-label">Current Pain Points</div>
        <div class="checkbox-group">
          ${painPoints.map(pain => `<div class="checkbox-item">${pain}</div>`).join('')}
        </div>
      </div>
    </div>
  </div>

  <!-- Requirements -->
  <div class="section">
    <div class="section-title">✅ Requirements & Expectations</div>
    <div class="field-group">
      <div class="field">
        <div class="field-label">Expected Go-Live Date</div>
        <div class="field-value">${new Date(expectedGoLiveDate).toLocaleDateString('en-IN')}</div>
      </div>
      <div class="field">
        <div class="field-label">Team Size</div>
        <div class="field-value">${teamSize || 'N/A'}</div>
      </div>
      <div class="field field-full">
        <div class="field-label">Features Interested In</div>
        <div class="checkbox-group">
          ${featuresInterested.map(feature => `<div class="checkbox-item">${feature}</div>`).join('')}
        </div>
      </div>
    </div>
  </div>

  <!-- Compliance -->
  <div class="section">
    <div class="section-title">📋 Compliance & Certifications</div>
    <div class="field-group">
      <div class="field">
        <div class="field-label">PAN Card</div>
        <div class="field-value">${panCard}</div>
      </div>
      <div class="field field-full">
        <div class="field-label">Certifications</div>
        <div class="checkbox-group">
          ${hasGSTCompliance ? '<div class="checkbox-item">GST Compliant</div>' : ''}
          ${hasHallmarkingCertification ? '<div class="checkbox-item">BIS Hallmarking</div>' : ''}
          ${hasFSSAILicense ? '<div class="checkbox-item">FSSAI License</div>' : ''}
        </div>
      </div>
    </div>
  </div>

  <!-- Additional Information -->
  ${comments || referralSource ? `
  <div class="section">
    <div class="section-title">ℹ️ Additional Information</div>
    <div class="field-group">
      ${referralSource ? `
      <div class="field">
        <div class="field-label">Referral Source</div>
        <div class="field-value">${formatReferralSource(referralSource)}</div>
      </div>
      ` : ''}
      ${comments ? `
      <div class="field field-full">
        <div class="field-label">Comments</div>
        <div class="field-value">${comments}</div>
      </div>
      ` : ''}
    </div>
  </div>
  ` : ''}

  <!-- Declaration -->
  <div class="declaration">
    <strong>DECLARATION:</strong> I/We hereby express our interest in participating in the GEMBank Pilot Program. 
    The information provided above is accurate to the best of my/our knowledge. I/We understand that this is an 
    expression of interest and does not constitute a binding agreement. GEMBank reserves the right to accept or 
    reject this application based on eligibility criteria and program capacity.
  </div>

  <!-- Signature Section -->
  <div class="signature-section">
    <div class="signature-box">
      <div style="margin-bottom: 50px;"></div>
      <strong>Authorized Signatory</strong><br>
      ${ownerName}
    </div>
    <div class="signature-box">
      <div style="margin-bottom: 50px;"></div>
      <strong>Date & Place</strong><br>
      ${submittedDate}
    </div>
  </div>

  <!-- Footer -->
  <div class="footer">
    <p><strong>GEMBank</strong> - Banking Designed for Jewellery Businesses</p>
    <p>📧 support@gembank.com | 📞 +91 1800 123 4567 | 🌐 www.gembank.com</p>
    <p style="margin-top: 10px; color: #999;">This is a computer-generated document. No signature is required.</p>
  </div>
</body>
</html>
  `;
}

// Helper functions for formatting
function formatBusinessType(type) {
  const types = {
    'retail': 'Retail',
    'wholesale': 'Wholesale',
    'manufacturing': 'Manufacturing',
    'mixed': 'Mixed Operations'
  };
  return types[type] || type;
}

function formatTurnover(value) {
  const ranges = {
    'below-1cr': 'Below ₹1 Crore',
    '1cr-5cr': '₹1 - 5 Crore',
    '5cr-10cr': '₹5 - 10 Crore',
    '10cr-25cr': '₹10 - 25 Crore',
    '25cr-50cr': '₹25 - 50 Crore',
    'above-50cr': 'Above ₹50 Crore',
    'below-50l': 'Below ₹50 Lakh',
    '50l-1cr': '₹50 Lakh - 1 Crore',
    '1cr-5cr': '₹1 - 5 Crore',
    'above-10cr': 'Above ₹10 Crore'
  };
  return ranges[value] || value;
}

function formatReferralSource(source) {
  const sources = {
    'google': 'Google Search',
    'social-media': 'Social Media',
    'referral': 'Friend/Colleague Referral',
    'trade-show': 'Trade Show/Event',
    'advertisement': 'Advertisement',
    'other': 'Other'
  };
  return sources[source] || source;
}